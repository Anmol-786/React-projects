import React from 'react';

const Sdata1 =[
    {
        id:1,
    img_src:"LOGO",
    img_name:"Complete CRM Platform",
    img_info:"Description"    
    },
    {
        id:2,
        img_src:"LOGO",
        img_name:"Mail",
        img_info:"Description"    
    },
    {
        id:3,
        img_src:"LOGO",
        img_name:"BOOKS",
        img_info:"Description"    
    },
    {
        id:4,
        img_src:"LOGO",
        img_name:"People",
        img_info:"Description"    
    },
    {
        id:5,
        img_src:"LOGO",
        img_name:"BackToWork",
        img_info:"Description"    
    },
   
]
export default Sdata1;