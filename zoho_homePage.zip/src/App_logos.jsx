import React from 'react';

const App_logo = (props)=>{
    return(
    <>
    <img src={props.img_src} alt={props.img_src} className="apps"/>
    </>)
}
export default App_logo;