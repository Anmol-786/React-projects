import React from 'react'

const Sdata5 = [
    {
        id:1,
    img_src:"LOGO",
    img_name:"Complete CRM Platform",
      
    },
    {
        id:2,
        img_src:"LOGO",
        img_name:"Mail",
            
    },
    {
        id:3,
        img_src:"LOGO",
        img_name:"BOOKS",
          
    },
    {
        id:4,
        img_src:"LOGO",
        img_name:"People",
        
    },
    {
        id:1,
    img_src:"LOGO",
    img_name:"Complete CRM Platform",
      
    },
    {
        id:2,
        img_src:"LOGO",
        img_name:"Mail",
            
    },
    {
        id:3,
        img_src:"LOGO",
        img_name:"BOOKS",
          
    },
    {
        id:4,
        img_src:"LOGO",
        img_name:"People",
        
    },

]
export default Sdata5;
