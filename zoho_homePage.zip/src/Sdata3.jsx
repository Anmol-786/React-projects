import React from 'react';

const Sdata3=[
    {
        id:1,
        img_src:"LOGO",
        img_name:"Your home-Office toolkit",
        img_info: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae, magnam tempore excepturi ad sunt recusandae. ipsum dol"   
    },
    {
        id:2,
        img_src:"LOGO",
        img_name:"Assist",
        img_info:"Lorem ipsum dolor sit amet"    
    },
    {
        id:3,
        img_src:"LOGO",
        img_name:"Meeting",
        img_info:"Lorem ipsum dolor sit amet"    
    },
    {
        id:4,
        img_src:"LOGO",
        img_name:"Projects",
        img_info:"Lorem ipsum dolor sit amet"    
    },
    {
        id:5,
        img_src:"LOGO",
        img_name:"Showtime",
        img_info:"Lorem ipsum dolor sit amet"    
    },
    {
        id:6,
        img_src:"LOGO",
        img_name:"Showtime",
        img_info:"Lorem ipsum dolor sit amet"    
    },
    {
        id:7,
        img_src:"LOGO",
        img_name:"IT Management",
        img_info:"Lorem ipsum dolor sit amet"    
    },
]
export default Sdata3;