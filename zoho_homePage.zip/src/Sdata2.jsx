import React from 'react';

const Sdata2 = [
    {
        id:1,
        img_src:"LOGO",
        img_name:"Your home-Office toolkit",
        img_info:"Description"    
    },
    {
        id:2,
        img_src:"LOGO",
        img_name:"Assist",
        img_info:"Description"    
    },
    {
        id:3,
        img_src:"LOGO",
        img_name:"Meeting",
        img_info:"Description"    
    },
    {
        id:4,
        img_src:"LOGO",
        img_name:"Projects",
        img_info:"Description"    
    },
    {
        id:5,
        img_src:"LOGO",
        img_name:"Showtime",
        img_info:"Description"    
    },
]
export default Sdata2